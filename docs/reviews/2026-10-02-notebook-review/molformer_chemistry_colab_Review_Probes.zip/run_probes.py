"""Probes for the Notebook Review Framework v1 review of tutorials/molformer_chemistry_colab.ipynb.

Reviewed revision: kurtvalcorza/molformer-chemistry-pipeline @ 12ba808bf448fad713ac70480f12ae393097ba90
(notebook blob dfb259ef480142ff4080f61696fbb09ba716442c, the blob of the recorded Kaggle T4 run of 2026-09-18).

Direct execution is LOCAL CPU ONLY (CUDA_VISIBLE_DEVICES="", OMP_NUM_THREADS=4, torch threads 4) in the build venv
`dimer-molformer` (Python 3.12.10, torch 2.14.0+cpu, transformers 5.17.0, huggingface-hub 1.32.0, tokenizers 0.23.2,
safetensors 0.8.0, numpy 2.5.3 = PINS; torchvision/torchaudio absent). The install cell runs with the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED=1 switch, so nothing is installed. HF_HOME and the working directory are empty scratch
directories, so the 7-file snapshot is fetched from the Hub at the pinned revision and digest-verified fresh.
`google.colab.files.upload` is a shim that returns prepared bytes ({} when nothing is queued, as for a cancelled
dialog). It is NOT a Colab run.

Usage: python run_probes.py <worktree> <scratch_dir> <phase>
  phase static : P1 static checks + generator --check + validator + offline pytest; P5 BYOD minimum arithmetic
  phase run    : P2 default Run all (cells 3..27), P3 exercises (EPOCHS=1; TRAINABLE_LAYERS=0) rerunning 21+23,
                 P4 BYOD (40-record CSV through 13..27; 24-record CSV that meets the stated contract; invalid inputs)
  phase determinism : P6 Section 6 check decomposed (same call twice, single vs padded batch, equal-length batch, classify)
  phase paren  : P7 one-character rule ("(" in SMILES -> branched) on the default sample
Results are merged into results.json next to this script; source_manifest.json is written by every phase.
"""
import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import time
import traceback
import types

WT, SCRATCH, PHASE = sys.argv[1], sys.argv[2], sys.argv[3]
HERE = os.path.dirname(os.path.abspath(__file__))
NB_REL = 'tutorials/molformer_chemistry_colab.ipynb'
NB_PATH = os.path.join(WT, NB_REL)
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['HF_HOME'] = os.path.join(SCRATCH, 'hf_home')
os.environ['HF_HUB_DISABLE_PROGRESS_BARS'] = '1'
os.environ.setdefault('OMP_NUM_THREADS', '4')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.makedirs(SCRATCH, exist_ok=True)

RES_PATH = os.path.join(HERE, 'results.json')
RESULTS = json.load(open(RES_PATH, encoding='utf-8')) if os.path.exists(RES_PATH) else {}


def save():
    with open(RES_PATH, 'w', encoding='utf-8') as fh:
        json.dump(RESULTS, fh, indent=1, default=str)


def sha256_file(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def git(*args):
    return subprocess.run(['git', '-C', WT, *args], capture_output=True, text=True).stdout.strip()


SOURCES = [NB_REL, 'tutorials/README.md', 'docs/release-verification.md', 'STATUS.md', 'README.md',
           'tools/build_notebook.py', 'tools/notebook_template.py', 'tools/validate_release_assets.py',
           'src/molformer_chemistry_pipeline/pipeline.py', 'src/molformer_chemistry_pipeline/samples.py',
           'src/molformer_chemistry_pipeline/metrics.py', 'pyproject.toml']
with open(os.path.join(HERE, 'source_manifest.json'), 'w', encoding='utf-8') as fh:
    json.dump({'revision': git('rev-parse', 'HEAD'), 'files': {p: sha256_file(os.path.join(WT, p)) for p in SOURCES}}, fh, indent=1)

NB = json.load(open(NB_PATH, encoding='utf-8'))
CELLS = NB['cells']
SRC = {i: ''.join(c['source']) for i, c in enumerate(CELLS)}
CODE = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'code']

UPLOADS = []


def install_colab_shim():
    google = types.ModuleType('google')
    colab = types.ModuleType('google.colab')
    files = types.ModuleType('google.colab.files')

    def upload():
        if not UPLOADS:
            return {}  # what Colab returns when the learner cancels the dialog
        name, payload = UPLOADS.pop(0)
        return {name: payload}

    files.upload = upload
    colab.files = files
    google.colab = colab
    sys.modules.update({'google': google, 'google.colab': colab, 'google.colab.files': files})


def run_cell(ns, idx, overrides=None, label=None):
    src = SRC[idx]
    for old, new in (overrides or {}).items():
        assert old in src, (idx, old)
        src = src.replace(old, new)
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(src, f'<cell {idx}>', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
            traceback.print_exc(file=buf)
    out = buf.getvalue()
    row = {'cell': idx, 'label': label, 'ok': err is None, 'error': err, 'seconds': round(time.perf_counter() - t0, 1),
           'stdout_tail': out[-2500:]}
    print(f'[cell {idx}{" " + label if label else ""}] ok={err is None} {row["seconds"]}s {err or ""}', file=sys.__stdout__, flush=True)
    return row


# ------------------------------------------------------------------------------------------------- BYOD data
def byod_records(n_per_class):
    """Two-class labelled set with aromatic rings, Cl and a charged bracket atom; ids/SMILES unique."""
    acids, amines = [], []
    for n in range(1, 40):
        acids.append('C' * n + 'C(=O)O')
        acids.append('c1ccc(cc1)' + 'C' * n + 'C(=O)O')
        amines.append('C' * n + 'N')
        amines.append('Clc1ccc(cc1)' + 'C' * n + '[NH3+]')
    rows = [{'id': f'acid_{i:03d}', 'smiles': s, 'label': 'carboxylic_acid'} for i, s in enumerate(acids[:n_per_class])]
    rows += [{'id': f'amine_{i:03d}', 'smiles': s, 'label': 'amine'} for i, s in enumerate(amines[:n_per_class])]
    return rows


def to_csv(rows, cols=('id', 'smiles', 'label')):
    lines = [','.join(cols)] + [','.join(str(r.get(c, '')) for c in cols) for r in rows]
    return ('\n'.join(lines) + '\n').encode()


# ------------------------------------------------------------------------------------------------- phase: static
if PHASE == 'static':
    p1 = {}
    p1['nbformat'] = [NB['nbformat'], NB['nbformat_minor']]
    p1['n_cells'] = len(CELLS)
    p1['code_cells'] = CODE
    p1['compile_errors'] = {}
    for i in CODE:
        try:
            compile(SRC[i], f'<cell {i}>', 'exec')
        except SyntaxError as exc:
            p1['compile_errors'][i] = str(exc)
    p1['persisted_outputs'] = sum(len(CELLS[i].get('outputs', [])) for i in CODE)
    p1['metadata_dimer'] = NB['metadata'].get('dimer')
    p1['head'] = git('rev-parse', 'HEAD')
    p1['notebook_blob_head'] = git('rev-parse', 'HEAD:' + NB_REL)
    p1['notebook_blob_recorded_run_7c2ab16'] = git('rev-parse', '7c2ab16:' + NB_REL)
    p1['carried_revision'] = NB['metadata']['dimer']['generated_from']['revision']
    p1['src_tools_changed_since_carried_revision'] = git('diff', '--stat', p1['carried_revision'], 'HEAD', '--', 'src', 'tools')
    p1['literal_double_braces_in_prereq'] = '{{id, smiles, label}}' in SRC[1]
    p1['env_var_documented_in_markdown'] = any('DIMER_NOTEBOOK_CI_PREINSTALLED' in SRC[i] for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown')
    # Remote-code contradiction: Section 3 markdown vs the intro / prerequisites / carried code
    p1['section3_says_no_remote_code'] = 'no remote model code is executed' in SRC[10].replace('\n', ' ')
    p1['section3_mentions_trust_remote_code'] = 'trust_remote_code' in SRC[10]
    p1['section3_mentions_deterministic_eval'] = 'deterministic_eval' in SRC[10]
    p1['intro_points_to_section3'] = 'explained in Section 3' in SRC[0]
    p1['prereq_points_to_section3'] = 'Section 3 explains why' in SRC[1]
    p1['section6_points_to_section3'] = 'see Section 3' in SRC[16]
    p1['trust_remote_code_true_in_cells'] = [i for i in CODE if 'trust_remote_code=True' in SRC[i]]
    p1['markdown_cells_mentioning_trust_remote_code'] = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown' and 'trust_remote_code' in SRC[i]]
    p1['generator_line_no_remote_code'] = [n + 1 for n, line in enumerate(open(os.path.join(WT, 'tools/build_notebook.py'), encoding='utf-8')) if 'no remote model code is' in line]
    p1['cell11_prints_load_report'] = any(k in SRC[11] for k in ('load_warnings', 'total_parameters', 'deterministic_eval', 'remote'))
    md = '\n'.join(SRC[i] for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown')
    lower = md.lower()
    p1['markdown_mentions'] = {k: (k in lower) for k in ('restart', 'troubleshoot', 'glossary', 'roadmap', 'how to use', 'predict', 'expected result', 'what to notice', 'look for', 'infrastructure', 'audience', 'checkpoint', 'conclusion', 'rerun', 're-run')}
    p1['run_all_paragraph_mentions_restart'] = 'restart' in SRC[0].split('**Run all:**')[1].split('**Bring Your Own Data:**')[0].lower()
    p1['section5_md_promises_three_syntax_rejections'] = 'three syntax rejections' in SRC[14]
    p1['byod_new_records_are_test_split'] = 'new_records = test_records[:6]' in SRC[25]
    p1['byod_writes_into_sample_dataset_filename'] = "write_dataset_csv(records, 'outputs/molformer_chemistry_sample_dataset.csv')" in SRC[13]
    p1['upload_unguarded_next_iter'] = 'next(iter(uploaded.items()))' in SRC[13]
    p1['figures_rendered_inline'] = any(k in SRC[i] for i in CODE for k in ('display(', 'plt.', 'imshow'))
    p1['exercise_text'] = SRC[28].split('**Optional experiments')[1].split('\n')[0][:500]
    py = sys.executable
    for name, cmd in (('build_check', [py, 'tools/build_notebook.py', '--check']),
                      ('validate_release_assets', [py, 'tools/validate_release_assets.py']),
                      ('pytest', [py, '-m', 'pytest', '-q', '-o', 'addopts=', 'tests', '-p', 'no:cacheprovider'])):
        env = dict(os.environ, PYTHONPATH=os.path.join(WT, 'src'))
        r = subprocess.run(cmd, cwd=WT, capture_output=True, text=True, env=env, timeout=500)
        p1[name] = {'exit': r.returncode, 'tail': (r.stdout + r.stderr)[-600:]}
    RESULTS['P1_static'] = p1
    save()

    # P5: stated BYOD contract (>=8 records, >=3 per class) vs what the pipeline later applies to the validation
    # split (pipe.adapt -> validate_dataset(val)) and to both evaluated splits (pipe.evaluate -> validate_dataset).
    sys.path.insert(0, os.path.join(WT, 'src'))
    from molformer_chemistry_pipeline.samples import split_dataset, validate_dataset
    p5 = {'by_n_per_class': {}}
    first_full_pass = None
    for k in range(3, 26):
        rows = byod_records(k)
        row = {'n_records': len(rows)}
        try:
            validate_dataset(rows)
            row['stated_contract'] = 'accepted'
        except ValueError as exc:
            row['stated_contract'] = f'rejected: {exc}'
            p5['by_n_per_class'][k] = row
            continue
        try:
            sp = split_dataset(rows, val_fraction=0.2, test_fraction=0.25, seed=42)
        except ValueError as exc:
            row['split'] = f'rejected: {exc}'
            p5['by_n_per_class'][k] = row
            continue
        row['sizes'] = {n: len(v) for n, v in sp.items()}
        verdicts = {}
        for part in ('train', 'validation', 'test'):
            try:
                validate_dataset(sp[part], classes=['amine', 'carboxylic_acid'])
                verdicts[part] = 'accepted'
            except ValueError as exc:
                verdicts[part] = f'rejected: {exc}'
        row['split_validation'] = verdicts
        if all(v == 'accepted' for v in verdicts.values()) and first_full_pass is None:
            first_full_pass = len(rows)
        p5['by_n_per_class'][k] = row
    p5['smallest_balanced_dataset_that_reaches_evaluation'] = first_full_pass
    RESULTS['P5_byod_minimum'] = p5
    save()
    print(json.dumps({'P1': {k: p1[k] for k in ('notebook_blob_head', 'notebook_blob_recorded_run_7c2ab16', 'section3_says_no_remote_code', 'build_check', 'validate_release_assets', 'pytest')}, 'P5_min': first_full_pass}, indent=1, default=str))

# ------------------------------------------------------------------------------------------------- phase: run
if PHASE == 'run':
    import torch
    torch.set_num_threads(4)
    work = os.path.join(SCRATCH, 'work_default')
    os.makedirs(work, exist_ok=True)
    os.chdir(work)
    install_colab_shim()
    ns = {'__name__': '__main__'}
    t0 = time.perf_counter()
    p2 = {'cells': []}
    for i in CODE:
        row = run_cell(ns, i)
        p2['cells'].append(row)
        if not row['ok']:
            break
    p2['wall_seconds'] = round(time.perf_counter() - t0, 1)
    p2['all_ok'] = all(r['ok'] for r in p2['cells']) and len(p2['cells']) == len(CODE)
    if p2['all_ok']:
        tm = ns['test_metrics']
        p2['summary'] = {
            'fetched': ns.get('fetched'), 'device': ns['pipe'].device, 'load_warnings': ns['pipe'].load_warnings[:5],
            'n_records': ns['dataset_manifest']['n_records'], 'splits': [len(ns['train_records']), len(ns['val_records']), len(ns['test_records'])],
            'baseline_majority': {k: ns['baseline_majority'][k] for k in ('accuracy', 'macro_f1')},
            'baseline_formula': {k: ns['baseline_formula'][k] for k in ('accuracy', 'macro_f1')},
            'trainable_parameters': ns['adapt_result']['trainable_parameters'], 'total_parameters': ns['adapt_result']['total_parameters'],
            'history': ns['adapt_result']['history'],
            'val': {k: ns['val_metrics'][k] for k in ('accuracy', 'macro_f1', 'auroc')},
            'test': {k: tm[k] for k in ('n', 'accuracy', 'macro_f1', 'auroc')},
            'new_molecule_matches': sum(p['label'] == r['label'] for p, r in zip(ns['predictions'], ns['new_records'])),
            'max_abs_score_diff': ns['max_score_diff'],
            'outputs': sorted(os.path.relpath(os.path.join(d, f), work).replace('\\', '/') for d, _, fs in os.walk('outputs') for f in fs),
            'cell11_stdout': p2['cells'][CODE.index(11)]['stdout_tail'][-900:],
            'cell15_stdout': p2['cells'][CODE.index(15)]['stdout_tail'],
            'cell17_stdout': p2['cells'][CODE.index(17)]['stdout_tail'][-600:],
        }
    RESULTS['P2_default'] = p2
    save()
    print(json.dumps(p2.get('summary', {}), indent=1, default=str)[:4000], flush=True)
    if not p2['all_ok']:
        sys.exit(1)

    # P3: the two documented optional experiments, rerunning only Sections 8 + 9 (the notebook names no rerun list).
    p3 = {}
    report_before = sha256_file('outputs/molformer_chemistry_evaluation_report.json')
    for name, ov in (('EPOCHS=1', {'EPOCHS = 4  #': 'EPOCHS = 1  #'}), ('TRAINABLE_LAYERS=0', {'TRAINABLE_LAYERS = 2  #': 'TRAINABLE_LAYERS = 0  #'})):
        r21 = run_cell(ns, 21, ov, name)
        r23 = run_cell(ns, 23, None, name)
        tm = ns['test_metrics']
        p3[name] = {'ok': r21['ok'] and r23['ok'], 'history': ns['adapt_result']['history'],
                    'trainable_parameters': ns['adapt_result']['trainable_parameters'],
                    'test': {k: tm[k] for k in ('accuracy', 'macro_f1', 'auroc')},
                    'val': {k: ns['val_metrics'][k] for k in ('accuracy', 'macro_f1', 'auroc')},
                    'adapt_seconds': ns['adapt_seconds']}
    p3['report_rewritten_by_cell23'] = sha256_file('outputs/molformer_chemistry_evaluation_report.json') != report_before
    p3['result_json_adaptation_epochs_after_exercises'] = json.load(open('outputs/molformer_chemistry_result.json', encoding='utf-8'))['evaluation_report']['adaptation']['epochs']
    p3['adapter_manifest_trainable_layers_after_exercises'] = json.load(open('outputs/molformer_chemistry_adapter/manifest.json', encoding='utf-8')).get('adaptation', {}).get('trainable_layers')
    RESULTS['P3_exercises'] = p3
    save()
    print(json.dumps(p3, indent=1, default=str)[:3000], flush=True)

    # P4: BYOD. The intro says: set USE_BYOD = True in Section 4 and re-run from that cell.
    p4 = {}
    ov_byod = {'USE_BYOD = False  #': 'USE_BYOD = True  #'}
    later = [c for c in CODE if c >= 13]
    UPLOADS.append(('my_molecules.csv', to_csv(byod_records(20))))
    rows = []
    for i in later:
        row = run_cell(ns, i, ov_byod if i == 13 else None, 'byod40')
        rows.append({k: row[k] for k in ('cell', 'ok', 'error', 'seconds')} | ({'stdout_tail': row['stdout_tail'][-900:]} if i in (13, 19, 21, 23, 25) else {}))
        if not row['ok']:
            break
    p4['byod_40'] = {'cells': rows, 'all_ok': all(r['ok'] for r in rows) and len(rows) == len(later)}
    if p4['byod_40']['all_ok']:
        p4['byod_40']['test'] = {k: ns['test_metrics'][k] for k in ('n', 'accuracy', 'macro_f1', 'auroc')}
        p4['byod_40']['formula_baseline'] = {k: ns['baseline_formula'][k] for k in ('accuracy', 'macro_f1')}
        p4['byod_40']['new_source'] = ns['new_source']
        p4['byod_40']['new_ids_all_in_test_split'] = all(r['id'] in {t['id'] for t in ns['test_records']} for r in ns['new_records'])
        p4['byod_40']['reload_max_abs_score_diff'] = ns['max_score_diff']
        p4['byod_40']['sample_dataset_csv_head'] = open('outputs/molformer_chemistry_sample_dataset.csv', encoding='utf-8').read()[:120]
    RESULTS['P4_byod'] = p4
    save()
    UPLOADS.append(('small.csv', to_csv(byod_records(12))))
    rows = []
    for i in later:
        row = run_cell(ns, i, ov_byod if i == 13 else None, 'byod24')
        rows.append({k: row[k] for k in ('cell', 'ok', 'error', 'seconds')})
        if not row['ok']:
            break
    p4['byod_24_meets_stated_contract'] = rows
    invalid = {
        'missing label column': ('nolabel.csv', to_csv(byod_records(10), cols=('id', 'smiles'))),
        'unpaired ring digit': ('badring.csv', to_csv(byod_records(10)[:-1] + [{'id': 'x1', 'smiles': 'c1ccccc', 'label': 'amine'}])),
        'one class only': ('oneclass.csv', to_csv([r for r in byod_records(20) if r['label'] == 'amine'])),
        'unsupported .xlsx': ('data.xlsx', b'PK\x03\x04'),
        'upload dialog cancelled': None,
    }
    inv = {}
    for name, item in invalid.items():
        if item is not None:
            UPLOADS.append(item)
        row = run_cell(ns, 13, ov_byod, name)
        inv[name] = row['error']
    p4['invalid'] = inv
    RESULTS['P4_byod'] = p4
    save()
    print(json.dumps(p4, indent=1, default=str)[:5000], flush=True)

# ------------------------------------------------------------------------------------------------- phase: determinism
# P6: Section 6 prints same_vector_on_a_second_call=False in the default run. Separate run-to-run nondeterminism
# from batch-composition (padding) dependence, and measure the effect on classifier scores. Uses the snapshot the
# 'run' phase staged in work_default (verify_snapshot re-hashes it; nothing is downloaded).
if PHASE == 'determinism':
    import torch
    torch.set_num_threads(4)
    work = os.path.join(SCRATCH, 'work_default')
    os.chdir(work)
    install_colab_shim()
    ns = {'__name__': '__main__'}
    for i in (3, 5, 7, 9, 11, 13):
        assert run_cell(ns, i)['ok']
    pipe, val, test = ns['pipe'], ns['val_records'], ns['test_records']
    smiles8 = [r['smiles'] for r in val[:8]]

    def maxdiff(a, b):
        return max(abs(x - y) for x, y in zip(a, b))

    p6 = {'smiles8': smiles8}
    b1 = pipe.embed(smiles8)['embeddings']
    b2 = pipe.embed(smiles8)['embeddings']
    s1 = pipe.embed([smiles8[0]])['embeddings'][0]
    s2 = pipe.embed([smiles8[0]])['embeddings'][0]
    p6['same_batch_twice_identical'] = b1 == b2
    p6['same_single_twice_identical'] = s1 == s2
    p6['single_vs_in_batch_max_abs_diff'] = maxdiff(s1, b1[0])
    p6['per_molecule_single_vs_in_batch_max_abs_diff'] = [maxdiff(pipe.embed([s])['embeddings'][0], b1[k]) for k, s in enumerate(smiles8)]
    tok = [pipe.token_count(s) for s in smiles8]
    p6['token_counts'] = tok
    longest = max(tok)
    p6['diff_zero_for_longest_molecules'] = [p6['per_molecule_single_vs_in_batch_max_abs_diff'][k] == 0.0 for k in range(8) if tok[k] == longest]
    # equal-length batch (no padding): duplicates of molecule 0 plus itself
    same_len = [s for s in [r['smiles'] for r in val + test + ns['train_records']] if pipe.token_count(s) == tok[0]][:4]
    if smiles8[0] not in same_len:
        same_len = [smiles8[0]] + same_len[:3]
    eq = pipe.embed(same_len)['embeddings'][same_len.index(smiles8[0])]
    p6['equal_length_batch_vs_single_max_abs_diff'] = maxdiff(eq, s1)
    # classifier: scores from pipe.evaluate-style batching vs one molecule at a time, after the default adaptation
    assert run_cell(ns, 19)['ok'] and run_cell(ns, 21)['ok']
    allrec = test + val
    batched = pipe.classify([r['smiles'] for r in allrec])['predictions']
    single = [pipe.classify([r['smiles']])['predictions'][0] for r in allrec]
    p6['classify_batch_vs_single_max_abs_score_diff'] = max(abs(a['score'] - b['score']) for a, b in zip(batched, single))
    p6['classify_label_flips'] = sum(a['label'] != b['label'] for a, b in zip(batched, single))
    RESULTS['P6_determinism'] = p6
    save()
    print(json.dumps(p6, indent=1, default=str), flush=True)

# ------------------------------------------------------------------------------------------------- phase: paren
# P7: a one-character rule ("contains '('" -> branched) on the default sample, the test split and the six new molecules.
if PHASE == 'paren':
    sys.path.insert(0, os.path.join(WT, 'src'))
    from molformer_chemistry_pipeline.samples import generate_sample_dataset, split_dataset
    recs = generate_sample_dataset()
    sp = split_dataset(recs, val_fraction=0.2, test_fraction=0.25, seed=42)
    new = generate_sample_dataset(seed=7, size=6)
    rule = lambda s: 'branched' if '(' in s else 'linear'  # noqa: E731
    RESULTS['P7_paren_rule'] = {name: [sum(rule(r['smiles']) == r['label'] for r in part), len(part)]
                                for name, part in (('all', recs), ('test', sp['test']), ('new_six', new))}
    save()
    print(RESULTS['P7_paren_rule'])
